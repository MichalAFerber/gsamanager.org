This zip file contains all of the files needed to support GSA Manager.

	1. These files should be copied to the "C:\GSA Manager" folder.